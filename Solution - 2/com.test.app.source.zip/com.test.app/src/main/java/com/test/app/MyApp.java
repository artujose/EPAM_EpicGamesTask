package com.test.app;

public class MyApp {

	public static void main(String args[]){
		System.out.println("My Java Standalone Application is running fine !!! ");
	}
}
